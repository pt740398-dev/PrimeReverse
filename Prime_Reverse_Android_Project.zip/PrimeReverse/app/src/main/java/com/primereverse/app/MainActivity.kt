package com.primereverse.app

import android.content.ContentValues
import android.net.Uri
import android.os.Bundle
import android.os.Environment
import android.provider.MediaStore
import android.widget.Toast
import androidx.activity.ComponentActivity
import androidx.activity.compose.rememberLauncherForActivityResult
import androidx.activity.compose.setContent
import androidx.activity.result.contract.ActivityResultContracts
import androidx.lifecycle.lifecycleScope
import kotlinx.coroutines.launch
import androidx.compose.foundation.background
import androidx.compose.foundation.layout.*
import androidx.compose.foundation.shape.RoundedCornerShape
import androidx.compose.material.icons.Icons
import androidx.compose.material.icons.filled.*
import androidx.compose.material3.*
import androidx.compose.runtime.*
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.graphics.Color
import androidx.compose.ui.text.font.FontWeight
import androidx.compose.ui.unit.dp
import androidx.compose.ui.unit.sp
import com.arthenica.ffmpegkit.FFmpegKit
import com.arthenica.ffmpegkit.ReturnCode
import kotlinx.coroutines.Dispatchers
import kotlinx.coroutines.withContext
import java.io.File
import java.text.SimpleDateFormat
import java.util.Date
import java.util.Locale

private val Ink = Color(0xFF090B12)
private val Panel = Color(0xFF151A27)
private val Accent = Color(0xFF7C5CFF)
private val Cyan = Color(0xFF3DD6D0)

class MainActivity : ComponentActivity() {
    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        setContent { PrimeReverseScreen() }
    }
}

@OptIn(ExperimentalMaterial3Api::class)
@Composable
private fun PrimeReverseScreen() {
    val context = androidx.compose.ui.platform.LocalContext.current
    var selectedUri by remember { mutableStateOf<Uri?>(null) }
    var selectedName by remember { mutableStateOf("No video selected") }
    var busy by remember { mutableStateOf(false) }
    var status by remember { mutableStateOf("Choose a video to get started") }
    var progress by remember { mutableStateOf(false) }
    var resultPath by remember { mutableStateOf<String?>(null) }

    val picker = rememberLauncherForActivityResult(
        ActivityResultContracts.GetContent()
    ) { uri ->
        if (uri != null) {
            selectedUri = uri
            selectedName = uri.lastPathSegment?.substringAfterLast('/') ?: "Selected video"
            resultPath = null
            status = "Video ready. Tap Reverse Video."
        }
    }

    MaterialTheme(
        colorScheme = darkColorScheme(
            background = Ink,
            surface = Panel,
            primary = Accent,
            secondary = Cyan
        )
    ) {
        Scaffold(containerColor = Ink) { padding ->
            Column(
                modifier = Modifier
                    .fillMaxSize()
                    .padding(padding)
                    .padding(horizontal = 20.dp, vertical = 18.dp),
                horizontalAlignment = Alignment.CenterHorizontally
            ) {
                Row(
                    modifier = Modifier.fillMaxWidth(),
                    verticalAlignment = Alignment.CenterVertically
                ) {
                    Surface(color = Accent, shape = RoundedCornerShape(14.dp)) {
                        Icon(
                            Icons.Default.Replay,
                            contentDescription = null,
                            tint = Color.White,
                            modifier = Modifier.padding(10.dp).size(27.dp)
                        )
                    }
                    Spacer(Modifier.width(12.dp))
                    Column {
                        Text("PRIME REVERSE", color = Color.White, fontWeight = FontWeight.Black, fontSize = 21.sp)
                        Text("Make every moment rewind", color = Color(0xFF9AA3B8), fontSize = 12.sp)
                    }
                    Spacer(Modifier.weight(1f))
                    Icon(Icons.Default.Hd, contentDescription = "Quality", tint = Cyan, modifier = Modifier.size(28.dp))
                }

                Spacer(Modifier.height(28.dp))

                Box(
                    modifier = Modifier
                        .fillMaxWidth()
                        .weight(1f)
                        .background(Panel, RoundedCornerShape(26.dp)),
                    contentAlignment = Alignment.Center
                ) {
                    Column(horizontalAlignment = Alignment.CenterHorizontally) {
                        Surface(
                            color = Color(0xFF24213C),
                            shape = RoundedCornerShape(24.dp)
                        ) {
                            Icon(
                                Icons.Default.Movie,
                                contentDescription = null,
                                tint = Accent,
                                modifier = Modifier.padding(25.dp).size(54.dp)
                            )
                        }
                        Spacer(Modifier.height(18.dp))
                        Text(
                            if (selectedUri == null) "Your video preview" else selectedName,
                            color = Color.White,
                            fontWeight = FontWeight.SemiBold,
                            fontSize = 16.sp
                        )
                        Spacer(Modifier.height(7.dp))
                        Text(
                            if (selectedUri == null) "Import a clip to begin" else "Ready for reverse processing",
                            color = Color(0xFF9AA3B8),
                            fontSize = 12.sp
                        )
                    }
                }

                Spacer(Modifier.height(18.dp))

                Button(
                    onClick = { picker.launch("video/*") },
                    modifier = Modifier.fillMaxWidth().height(54.dp),
                    shape = RoundedCornerShape(16.dp),
                    colors = ButtonDefaults.buttonColors(containerColor = Panel)
                ) {
                    Icon(Icons.Default.VideoLibrary, contentDescription = null)
                    Spacer(Modifier.width(9.dp))
                    Text("SELECT VIDEO", fontWeight = FontWeight.Bold)
                }

                Spacer(Modifier.height(12.dp))

                Button(
                    onClick = {
                        val uri = selectedUri ?: return@Button
                        busy = true
                        progress = true
                        status = "Preparing video…"
                        val activity = context as ComponentActivity
                        activity.lifecycleScope.launch {
                            try {
                                val input = withContext(Dispatchers.IO) {
                                    val f = File(context.cacheDir, "prime_reverse_input.mp4")
                                    context.contentResolver.openInputStream(uri).use { source ->
                                        requireNotNull(source) { "Cannot open selected video" }.copyTo(f.outputStream())
                                    }
                                    f
                                }
                                val output = File(context.cacheDir, "prime_reverse_${System.currentTimeMillis()}.mp4")
                                val command = "-y -i \"${input.absolutePath}\" -vf reverse -an -c:v mpeg4 -q:v 2 -pix_fmt yuv420p -movflags +faststart \"${output.absolutePath}\""
                                status = "Reversing frames… keep the app open"
                                FFmpegKit.executeAsync(command) { session ->
                                    val success = ReturnCode.isSuccess(session.returnCode)
                                    activity.runOnUiThread {
                                        busy = false
                                        progress = false
                                        if (success && output.exists() && output.length() > 0) {
                                            resultPath = output.absolutePath
                                            status = "Reverse complete. Saving to Movies…"
                                            activity.lifecycleScope.launch {
                                                try {
                                                    val saved = activity.saveToMovies(output)
                                                    status = if (saved) "Saved in Movies / PrimeReverse" else "Export ready in app storage"
                                                    Toast.makeText(activity, status, Toast.LENGTH_LONG).show()
                                                } catch (e: Exception) {
                                                    status = "Export created, but gallery save failed"
                                                }
                                            }
                                        } else {
                                            status = "Could not reverse this file. Try a shorter MP4 clip."
                                        }
                                    }
                                }
                            } catch (e: Exception) {
                                busy = false
                                progress = false
                                status = e.message ?: "Something went wrong"
                            }
                        }
                    },
                    enabled = selectedUri != null && !busy,
                    modifier = Modifier.fillMaxWidth().height(58.dp),
                    shape = RoundedCornerShape(16.dp),
                    colors = ButtonDefaults.buttonColors(containerColor = Accent)
                ) {
                    if (busy) {
                        CircularProgressIndicator(color = Color.White, modifier = Modifier.size(20.dp), strokeWidth = 2.dp)
                        Spacer(Modifier.width(10.dp))
                    } else {
                        Icon(Icons.Default.FastRewind, contentDescription = null)
                        Spacer(Modifier.width(9.dp))
                    }
                    Text(if (busy) "PROCESSING…" else "REVERSE VIDEO", fontWeight = FontWeight.ExtraBold)
                }

                Spacer(Modifier.height(14.dp))
                Text(status, color = if (status.contains("complete") || status.contains("Saved")) Cyan else Color(0xFFADB5C7), fontSize = 12.sp)
                Spacer(Modifier.height(10.dp))
                Text("Tip: Short clips process faster. Audio is muted in this first build.", color = Color(0xFF69748B), fontSize = 11.sp)
            }
        }
    }
}

private suspend fun MainActivity.saveToMovies(source: File): Boolean = withContext(Dispatchers.IO) {
    val values = ContentValues().apply {
        put(MediaStore.Video.Media.DISPLAY_NAME, "PrimeReverse_${SimpleDateFormat("yyyyMMdd_HHmmss", Locale.US).format(Date())}.mp4")
        put(MediaStore.Video.Media.MIME_TYPE, "video/mp4")
        put(MediaStore.Video.Media.RELATIVE_PATH, "${Environment.DIRECTORY_MOVIES}/PrimeReverse")
        put(MediaStore.Video.Media.IS_PENDING, 1)
    }
    val resolver = contentResolver
    val uri = resolver.insert(MediaStore.Video.Media.EXTERNAL_CONTENT_URI, values) ?: return@withContext false
    resolver.openOutputStream(uri)?.use { out -> source.inputStream().use { it.copyTo(out) } }
    values.clear()
    values.put(MediaStore.Video.Media.IS_PENDING, 0)
    resolver.update(uri, values, null, null)
    true
}
