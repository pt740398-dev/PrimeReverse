# Prime Reverse

An original Android video reverse app prototype.

## Current features
- Pick a video from Android storage.
- Reverse video frames locally using FFmpeg.
- Mute audio in this first version.
- Export the result to Movies/PrimeReverse.
- Compose-based dark interface.

## Important notes
- The `reverse` video filter buffers frames. Start with short clips; long/high-resolution clips can require substantial temporary storage and memory.
- This first prototype uses MPEG-4 Part 2 encoding (`-q:v 2`) for broad compatibility. It is not lossless and does not promise 4K/60fps on every phone.
- The preview panel is a placeholder; playback preview and progress percentage are planned for a later version.
- FFmpegKit-compatible dependency is the community-maintained LGPL Android package. Review its license and notices before distributing the app.

## Build
Open this project in Android Studio, or use the included GitHub Actions workflow.
